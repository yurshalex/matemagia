"""ProgressService: попытки решения и показатели успеваемости."""
import logging

from django.core.paginator import Paginator
from django.db import DatabaseError, transaction
from django.db.models import Sum

from core.results import ResultCode, ServiceResult
from learning.models import Topic
from tests.models import Task

from .models import SolutionAttempt, UserProgress

logger = logging.getLogger(__name__)


def _percent(correct: int, total: int) -> float:
    return round(correct / total * 100, 1) if total else 0.0


class ProgressService:
    WEAK_TOPIC_PERCENT = 60
    WEAK_TOPIC_MIN_ATTEMPTS = 3
    HISTORY_PAGE_SIZE = 20

    def record_attempt(self, user, task, user_answer, is_correct, xp_earned) -> ServiceResult:
        try:
            with transaction.atomic():
                attempt = SolutionAttempt.objects.create(
                    user=user, task=task, user_answer=user_answer, is_correct=is_correct, xp_earned=xp_earned
                )
                progress, _ = UserProgress.objects.get_or_create(user=user, topic_id=task.topic_id)
                progress.tasks_solved += 1
                if is_correct:
                    progress.tasks_correct += 1
                progress.error_rate = round(
                    (progress.tasks_solved - progress.tasks_correct) / progress.tasks_solved * 100, 1
                )
                progress.save(update_fields=["tasks_solved", "tasks_correct", "error_rate"])
        except DatabaseError:
            logger.exception("Не удалось сохранить попытку")
            return ServiceResult.fail(ResultCode.INTERNAL_ERROR, {"__all__": "Ошибка записи в БД"})
        return ServiceResult.success(attempt)

    def get_user_stats(self, user) -> ServiceResult:
        totals = UserProgress.objects.filter(user=user).aggregate(s=Sum("tasks_solved"), c=Sum("tasks_correct"))
        total, correct = totals["s"] or 0, totals["c"] or 0
        return ServiceResult.success(
            {"total": total, "correct": correct, "wrong": total - correct, "percent_correct": _percent(correct, total)}
        )

    def get_topic_progress(self, user, topic_id=None) -> ServiceResult:
        if topic_id is not None and not Topic.objects.filter(pk=topic_id).exists():
            return ServiceResult.fail(ResultCode.NOT_FOUND, {"topic": "Тема не найдена"})
        rows = UserProgress.objects.filter(user=user).select_related("topic").order_by("topic__order", "topic_id")
        if topic_id is not None:
            rows = rows.filter(topic_id=topic_id)
        return ServiceResult.success(
            [
                {
                    "topic": r.topic,
                    "tasks_solved": r.tasks_solved,
                    "tasks_correct": r.tasks_correct,
                    "percent_correct": _percent(r.tasks_correct, r.tasks_solved),
                }
                for r in rows
            ]
        )

    def get_history(self, user, page=1) -> ServiceResult:
        try:
            number = int(page)
        except (TypeError, ValueError):
            number = 0
        if number < 1:
            return ServiceResult.fail(ResultCode.VALIDATION_ERROR, {"page": "Номер страницы должен быть положительным"})

        attempts = (
            SolutionAttempt.objects.filter(user=user).select_related("task", "task__topic").order_by("-created_at", "-id")
        )
        paginator = Paginator(attempts, self.HISTORY_PAGE_SIZE)
        if number > paginator.num_pages:
            return ServiceResult.fail(ResultCode.NOT_FOUND, {"page": "Страница не найдена"})
        page_obj = paginator.page(number)
        return ServiceResult.success(
            {
                "attempts": list(page_obj.object_list),
                "page": number,
                "num_pages": paginator.num_pages,
                "has_next": page_obj.has_next(),
                "has_previous": page_obj.has_previous(),
                "total": paginator.count,
            }
        )

    def get_recent_attempts(self, user, limit=5) -> ServiceResult:
        rows = (
            SolutionAttempt.objects.filter(user=user).select_related("task", "task__topic").order_by("-created_at", "-id")[:limit]
        )
        return ServiceResult.success(list(rows))

    def get_weak_topics(self, user) -> ServiceResult:
        """Процент верных < 60 при не менее 3 попыток; самая слабая тема — первая."""
        weak = []
        for row in UserProgress.objects.filter(user=user).select_related("topic"):
            if row.tasks_solved < self.WEAK_TOPIC_MIN_ATTEMPTS:
                continue
            percent = _percent(row.tasks_correct, row.tasks_solved)
            if percent < self.WEAK_TOPIC_PERCENT:
                weak.append({"topic_id": row.topic_id, "topic_title": row.topic.title, "percent_correct": percent})
        weak.sort(key=lambda item: item["percent_correct"])
        return ServiceResult.success(weak)

    def get_error_tasks(self, user) -> ServiceResult:
        """Задания, последняя попытка по которым неверна (отдельной таблицы ошибок нет)."""
        last = {}
        rows = SolutionAttempt.objects.filter(user=user).order_by("-created_at", "-id").values_list("task_id", "is_correct")
        for task_id, is_correct in rows:
            last.setdefault(task_id, is_correct)
        error_ids = [task_id for task_id, ok in last.items() if not ok]
        return ServiceResult.success(list(Task.objects.filter(pk__in=error_ids).select_related("topic")))

    def get_recent_accuracy(self, user, topic_id, n) -> ServiceResult:
        results = list(
            SolutionAttempt.objects.filter(user=user, task__topic_id=topic_id)
            .order_by("-created_at", "-id")
            .values_list("is_correct", flat=True)[:n]
        )
        return ServiceResult.success({"attempts": len(results), "correct": sum(results), "results": results})

    # --- вспомогательные методы для других сервисов ---
    def last_attempt_incorrect(self, user, task_id) -> bool:
        last = SolutionAttempt.objects.filter(user=user, task_id=task_id).order_by("-created_at", "-id").first()
        return last is not None and not last.is_correct

    def get_recent_task_ids(self, user, limit=10) -> list[int]:
        ids: list[int] = []
        rows = SolutionAttempt.objects.filter(user=user).order_by("-created_at", "-id").values_list("task_id", flat=True)
        for task_id in rows.iterator():
            if task_id not in ids:
                ids.append(task_id)
                if len(ids) >= limit:
                    break
        return ids
