from django.conf import settings
from django.db import models


class SolutionAttempt(models.Model):
    """История решений (таблица progress_solutionattempt)."""

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="attempts")
    task = models.ForeignKey("tests.Task", on_delete=models.CASCADE, related_name="attempts")
    user_answer = models.TextField()
    is_correct = models.BooleanField()
    xp_earned = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [models.Index(fields=["user", "-created_at"], name="progress_att_user_created_idx")]


class UserProgress(models.Model):
    """Агрегированный прогресс по темам (таблица progress_userprogress)."""

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="topic_progress")
    topic = models.ForeignKey("learning.Topic", on_delete=models.CASCADE, related_name="user_progress")
    tasks_solved = models.IntegerField(default=0)
    tasks_correct = models.IntegerField(default=0)
    error_rate = models.FloatField(default=0.0)
    difficulty_level = models.IntegerField(default=1)  # текущий уровень сложности темы
    # служебное: при каком tasks_solved уровень пересматривался в последний раз
    difficulty_reviewed_at = models.IntegerField(default=0)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["user", "topic"], name="uniq_user_topic_progress")]
