"""ProgressViews: статистика, история решений, анализ ошибок."""
from django.contrib.auth.decorators import login_required
from django.http import Http404, HttpResponseBadRequest
from django.shortcuts import render
from django.views.decorators.http import require_GET

from core.results import ResultCode

from .services import ProgressService

progress_service = ProgressService()


@login_required
@require_GET
def progress_view(request):
    topic_raw = request.GET.get("topic")
    topic_id = None
    if topic_raw:
        if not topic_raw.isdigit():
            return HttpResponseBadRequest("Параметр topic должен быть числом")
        topic_id = int(topic_raw)

    stats = progress_service.get_user_stats(request.user)
    topics = progress_service.get_topic_progress(request.user, topic_id)
    if topics.code == ResultCode.NOT_FOUND:
        raise Http404("Тема не найдена")
    return render(request, "progress/progress.html", {"stats": stats.data, "topic_progress": topics.data})


@login_required
@require_GET
def history_view(request):
    result = progress_service.get_history(request.user, request.GET.get("page", 1))
    if result.code == ResultCode.VALIDATION_ERROR:
        return HttpResponseBadRequest("Параметр page должен быть положительным числом")
    if result.code == ResultCode.NOT_FOUND:
        raise Http404("Страница не найдена")
    return render(request, "progress/history.html", result.data)


@login_required
@require_GET
def error_analysis_view(request):
    weak = progress_service.get_weak_topics(request.user)
    errors = progress_service.get_error_tasks(request.user)
    return render(request, "progress/weak_topics.html", {"weak_topics": weak.data, "error_tasks": errors.data})
