"""RewardService (опыт, ранги, достижения) и ChallengeService (режим «Испытание»)."""
import logging
from datetime import timedelta

from django.conf import settings
from django.db import DatabaseError, transaction
from django.utils import timezone

from core.results import ResultCode, ServiceResult
from learning.models import Topic
from progress.models import SolutionAttempt
from tests.models import Task

from .models import Achievement, ChallengeResult, UserAchievement

logger = logging.getLogger(__name__)


class RewardService:
    """XP = BASE_XP × DIFFICULTY_COEF[сложность] + бонус за серию верных ответов подряд."""

    def __init__(self):
        self.rank_thresholds = sorted(settings.RANK_THRESHOLDS)
        self.achievement_rules = {
            "first_task": lambda user, ctx: self._solved_count(user) >= 1,
            "ten_tasks": lambda user, ctx: self._solved_count(user) >= 10,
            "fifty_tasks": lambda user, ctx: self._solved_count(user) >= 50,
            "century": lambda user, ctx: self._solved_count(user) >= 100,
            "no_errors": self._rule_no_errors,
            "three_challenges": lambda user, ctx: self.count_passed_challenges(user) >= 3,
            "week_streak": self._rule_week_streak,
            "fix_errors": lambda user, ctx: bool(ctx and ctx.get("fixed_error")),
        }

    # --- опыт ---
    def calculate_xp(self, difficulty, streak) -> ServiceResult:
        if difficulty not in settings.DIFFICULTY_COEF:
            return ServiceResult.fail(ResultCode.VALIDATION_ERROR, {"difficulty": "Недопустимая сложность"})
        xp = round(settings.BASE_XP * settings.DIFFICULTY_COEF[difficulty])
        if streak >= settings.STREAK_MIN:
            xp += settings.STREAK_BONUS_XP
        return ServiceResult.success(int(xp))

    def get_streak(self, user) -> ServiceResult:
        streak = 0
        rows = SolutionAttempt.objects.filter(user=user).order_by("-created_at", "-id").values_list("is_correct", flat=True)
        for is_correct in rows.iterator():
            if not is_correct:
                break
            streak += 1
        return ServiceResult.success(streak)

    def award_xp(self, user, xp, context=None) -> ServiceResult:
        if xp < 0:
            return ServiceResult.fail(ResultCode.VALIDATION_ERROR, {"xp": "Опыт не может быть отрицательным"})
        try:
            with transaction.atomic():
                user.current_xp += xp
                rank = self.update_rank(user)
                new_codes = self.check_achievements(user, context)
                if not new_codes.ok:
                    return new_codes
                user.save(update_fields=["current_xp", "current_rank"])
        except DatabaseError:
            logger.exception("Не удалось начислить опыт")
            return ServiceResult.fail(ResultCode.INTERNAL_ERROR, {"__all__": "Ошибка записи в БД"})
        return ServiceResult.success(
            {
                "total_xp": user.current_xp,
                "rank": rank.data["rank"],
                "rank_changed": rank.data["changed"],
                "new_achievements": new_codes.data,
            }
        )

    # --- ранги ---
    def _rank_index(self, xp):
        index = 0
        for i, (threshold, _name) in enumerate(self.rank_thresholds):
            if threshold <= xp:
                index = i
        return index

    def update_rank(self, user) -> ServiceResult:
        """Меняет user.current_rank в памяти; сохраняет вызывающий (award_xp)."""
        rank = self.rank_thresholds[self._rank_index(user.current_xp)][1]
        changed = rank != user.current_rank
        user.current_rank = rank
        return ServiceResult.success({"rank": rank, "changed": changed})

    def get_rank_info(self, user) -> ServiceResult:
        index = self._rank_index(user.current_xp)
        current_threshold, rank = self.rank_thresholds[index]
        if index + 1 < len(self.rank_thresholds):
            next_threshold, next_rank = self.rank_thresholds[index + 1]
            span = next_threshold - current_threshold
            progress = round((user.current_xp - current_threshold) / span * 100) if span else 100
            xp_to_next = max(next_threshold - user.current_xp, 0)
        else:
            next_threshold, next_rank, progress, xp_to_next = None, None, 100, 0
        return ServiceResult.success(
            {
                "rank": rank,
                "xp": user.current_xp,
                "next_rank": next_rank,
                "next_threshold": next_threshold,  # для подписи «120 / 300»
                "xp_to_next": xp_to_next,
                "progress_percent": progress,
                "ranks": [{"threshold": t, "name": n} for t, n in self.rank_thresholds],  # «Путь мага»
            }
        )

    # --- достижения ---
    def check_achievements(self, user, context=None) -> ServiceResult:
        """Возвращает коды вновь полученных достижений."""
        new_codes = []
        try:
            owned = set(UserAchievement.objects.filter(user=user).values_list("achievement_id", flat=True))
            for achievement in Achievement.objects.exclude(pk__in=owned):
                rule = self.achievement_rules.get(achievement.code)
                if rule and rule(user, context):
                    UserAchievement.objects.create(user=user, achievement=achievement)
                    new_codes.append(achievement.code)
        except DatabaseError:
            logger.exception("Не удалось выдать достижения")
            return ServiceResult.fail(ResultCode.INTERNAL_ERROR, {"__all__": "Ошибка записи в БД"})
        return ServiceResult.success(new_codes)

    def get_achievements(self, user) -> ServiceResult:
        unlocked = {ua.achievement_id: ua.unlocked_at for ua in UserAchievement.objects.filter(user=user)}
        items = [
            {
                "code": a.code,
                "title": a.title,
                "description": a.description,
                "icon_code": a.icon_code,
                "unlocked": a.pk in unlocked,
                "unlocked_at": unlocked.get(a.pk),
            }
            for a in Achievement.objects.order_by("id")
        ]
        return ServiceResult.success({"achievements": items, "unlocked_count": len(unlocked), "total_count": len(items)})

    def count_passed_challenges(self, user) -> int:
        return ChallengeResult.objects.filter(user=user, success=True).count()

    @staticmethod
    def _solved_count(user) -> int:
        return SolutionAttempt.objects.filter(user=user, is_correct=True).values("task_id").distinct().count()

    @staticmethod
    def _rule_no_errors(user, context) -> bool:
        result = (context or {}).get("challenge")
        return bool(result and result["total"] > 0 and result["correct"] == result["total"])

    @staticmethod
    def _rule_week_streak(user, context) -> bool:
        days = {d.date() for d in SolutionAttempt.objects.filter(user=user).datetimes("created_at", "day")}
        today = timezone.localdate()
        return all(today - timedelta(days=i) in days for i in range(7))


class ChallengeService:
    """Серия из CHALLENGE_TASKS_COUNT заданий; состояние — в session['challenge']."""

    def __init__(self, task_service=None, reward_service=None):
        if task_service is None:
            from tests.services import TaskService  # отложенный импорт: tests.services импортирует game.services

            task_service = TaskService()
        self.taskService = task_service
        self.rewardService = reward_service or RewardService()

    @staticmethod
    def difficulty_for(position: int) -> int:
        """Задания 1-3 — сложность 1, 4-7 — сложность 2, 8-10 — сложность 3."""
        return 1 if position <= 3 else 2 if position <= 7 else 3

    def start_challenge(self, session, user, topic_id) -> ServiceResult:
        if not Topic.objects.filter(pk=topic_id).exists():
            return ServiceResult.fail(ResultCode.NOT_FOUND, {"topic": "Тема не найдена"})
        session.pop("challenge_result", None)
        session.pop("challenge", None)

        first = self.taskService.get_next_task(user, topic_id, None, difficulty=self.difficulty_for(1))
        if not first.ok:
            return first
        total = settings.CHALLENGE_TASKS_COUNT
        session["challenge"] = {
            "topic_id": topic_id,
            "position": 1,
            "total": total,
            "task_id": first.data["id"],
            "correct": 0,
            "score": 0,
            "answered": 0,
            "xp": 0,
        }
        session.modified = True
        return ServiceResult.success({"position": 1, "total": total})

    def get_current_task(self, session) -> ServiceResult:
        state = session.get("challenge")
        if not state:
            return ServiceResult.fail(ResultCode.CHALLENGE_NOT_ACTIVE, {"challenge": "Испытание не запущено"})
        task = self.taskService.get_task(state["task_id"])
        if not task.ok:
            return task
        return ServiceResult.success({"task": task.data, "position": state["position"], "total": state["total"]})

    def submit_answer(self, session, user, raw_answer) -> ServiceResult:
        state = session.get("challenge")
        if not state:
            return ServiceResult.fail(ResultCode.CHALLENGE_NOT_ACTIVE, {"challenge": "Испытание не запущено"})

        checked = self.taskService.check_answer(user, state["task_id"], raw_answer)
        if not checked.ok:
            return checked  # 3001: позиция не меняется

        task = Task.objects.filter(pk=state["task_id"]).first()
        is_correct = checked.data["is_correct"]
        state["answered"] += 1
        state["xp"] += checked.data["xp_earned"]
        if is_correct:
            state["correct"] += 1
            state["score"] += task.difficulty_level if task else 0  # сумма сложностей верно решённых

        position = state["position"]
        nxt = None
        if position < state["total"]:
            nxt = self.taskService.get_next_task(
                user, state["topic_id"], None, difficulty=self.difficulty_for(position + 1)
            )
        if nxt is None or not nxt.ok:
            if nxt is not None:
                state["total"] = position  # заданий больше нет: завершаем по решённым
            session["challenge"] = state
            session.modified = True
            finished = self.finish_challenge(session, user)
            if not finished.ok:
                return finished
            return ServiceResult.success({"is_correct": is_correct, "finished": True, "position": position})

        state["position"] = position + 1
        state["task_id"] = nxt.data["id"]
        session["challenge"] = state
        session.modified = True
        return ServiceResult.success({"is_correct": is_correct, "finished": False, "position": state["position"]})

    def finish_challenge(self, session, user) -> ServiceResult:
        state = session.get("challenge")
        if not state:
            return ServiceResult.fail(ResultCode.CHALLENGE_NOT_ACTIVE, {"challenge": "Испытание не запущено"})
        if state["answered"] < state["total"]:
            return ServiceResult.fail(ResultCode.CHALLENGE_NOT_FINISHED, {"challenge": "Даны ответы не на все задания"})

        correct, total = state["correct"], state["total"]
        success = correct * 100 >= settings.CHALLENGE_SUCCESS_PERCENT * total
        try:
            with transaction.atomic():
                ChallengeResult.objects.create(
                    user=user, topic_id=state["topic_id"], correct=correct, total=total,
                    score=state["score"], success=success,
                )
                bonus, rank_changed, new_codes = 0, False, []
                if success:
                    award = self.rewardService.award_xp(user, settings.CHALLENGE_BONUS_XP)
                    if not award.ok:
                        raise DatabaseError("award_xp failed")
                    bonus = settings.CHALLENGE_BONUS_XP
                    rank_changed = award.data["rank_changed"]
                    new_codes = list(award.data["new_achievements"])
                context = {"challenge": {"correct": correct, "total": total, "success": success}}
                extra = self.rewardService.check_achievements(user, context)
                if not extra.ok:
                    raise DatabaseError("check_achievements failed")
                new_codes += [c for c in extra.data if c not in new_codes]
        except DatabaseError:
            logger.exception("Не удалось завершить испытание")
            return ServiceResult.fail(ResultCode.INTERNAL_ERROR, {"__all__": "Ошибка записи в БД"})

        result = {
            "correct": correct,
            "total": total,
            "score": state["score"],
            "success": success,
            "bonus_xp": bonus,
            "xp_total": state["xp"] + bonus,
            "rank": user.current_rank,
            "rank_changed": rank_changed,
            "new_achievements": new_codes,
        }
        session["challenge_result"] = result
        session.pop("challenge", None)
        session.modified = True
        return ServiceResult.success(result)

    def get_result(self, session) -> ServiceResult:
        result = session.get("challenge_result")
        if not result:
            return ServiceResult.fail(ResultCode.CHALLENGE_NOT_ACTIVE, {"challenge": "Завершённого испытания нет"})
        return ServiceResult.success(result)
