"""GameViews: режим «Испытание», ранги и достижения."""
from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import Http404, HttpResponseBadRequest
from django.shortcuts import redirect, render
from django.views.decorators.http import require_GET, require_http_methods, require_POST

from core.results import ResultCode
from learning.models import Topic
from tests.forms import AnswerForm

from .services import ChallengeService, RewardService

challenge_service = ChallengeService()
reward_service = RewardService()


def _start_context(request):
    rank = reward_service.get_rank_info(request.user)
    return {
        "mode": "start",
        "rank_info": rank.data if rank.ok else None,
        "topics": Topic.objects.all(),
        "challenge_params": {
            "tasks_count": settings.CHALLENGE_TASKS_COUNT,
            "success_percent": settings.CHALLENGE_SUCCESS_PERCENT,
            "bonus_xp": settings.CHALLENGE_BONUS_XP,
        },
    }


@login_required
@require_POST
def game_start_view(request):
    topic_raw = request.POST.get("topic_id") or request.POST.get("topic", "")
    if not topic_raw.isdigit():
        return HttpResponseBadRequest("Поле topic_id отсутствует или не является числом")

    result = challenge_service.start_challenge(request.session, request.user, int(topic_raw))
    if result.code == ResultCode.NOT_FOUND:
        raise Http404("Тема не найдена")
    if not result.ok:
        messages.error(request, "Для выбранной темы пока нет подходящих заданий")
    return redirect("/game/")


@login_required
@require_http_methods(["GET", "POST"])
def game_session_view(request):
    state = request.session.get("challenge")

    if request.method == "POST":
        if not state:
            return redirect("/game/")
        form = AnswerForm(request.POST)
        answer = form.cleaned_data["answer"] if form.is_valid() else ""
        result = challenge_service.submit_answer(request.session, request.user, answer)
        if result.ok:
            return redirect("/game/result/" if result.data["finished"] else "/game/")
        if result.code in (ResultCode.INVALID_ANSWER_FORMAT, ResultCode.VALIDATION_ERROR):
            return _render_task(request, errors=result.errors)  # повторный показ задания, 200
        if result.code in (ResultCode.NOT_FOUND, ResultCode.NO_TASKS_AVAILABLE):
            raise Http404("Для темы испытания не найдено подходящих заданий")
        if result.code == ResultCode.CHALLENGE_NOT_ACTIVE:
            return redirect("/game/")
        raise RuntimeError(f"submit_answer failed: {result.code} {result.errors}")

    if not state:
        return render(request, "game/challenge_game.html", _start_context(request))
    return _render_task(request)


def _render_task(request, errors=None):
    current = challenge_service.get_current_task(request.session)
    if not current.ok:
        if current.code == ResultCode.NOT_FOUND:
            raise Http404("Задание испытания не найдено")
        return redirect("/game/")
    return render(request, "game/challenge_game.html", {"mode": "task", "errors": errors or {}, **current.data})


@login_required
@require_GET
def game_result_view(request):
    result = challenge_service.get_result(request.session)
    if not result.ok:
        return redirect("/game/")
    return render(request, "game/game_result.html", {"result": result.data})


@login_required
@require_GET
def achievements_view(request):
    rank = reward_service.get_rank_info(request.user)
    achievements = reward_service.get_achievements(request.user)
    return render(request, "game/achievements_list.html", {"rank_info": rank.data, "achievements": achievements.data})
