from django.conf import settings
from django.db import models


class Achievement(models.Model):
    """Справочник достижений (таблица game_achievement)."""

    code = models.CharField(max_length=50, unique=True)
    title = models.CharField(max_length=100)
    description = models.TextField()
    icon_code = models.CharField(max_length=50)

    def __str__(self) -> str:
        return self.title


class UserAchievement(models.Model):
    """Полученные достижения (таблица game_userachievement)."""

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="achievements")
    achievement = models.ForeignKey(Achievement, on_delete=models.CASCADE, related_name="awards")
    unlocked_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["user", "achievement"], name="uniq_user_achievement")]


class ChallengeResult(models.Model):
    """Итог завершённого «Испытания» (дополнение к 8 таблицам документа).

    Нужен для достижения three_challenges и показателя «Пройдено испытаний»;
    состояние активного испытания по-прежнему хранится только в сессии."""

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="challenge_results")
    topic = models.ForeignKey("learning.Topic", on_delete=models.SET_NULL, null=True, related_name="+")
    correct = models.IntegerField()
    total = models.IntegerField()
    score = models.IntegerField()
    success = models.BooleanField()
    created_at = models.DateTimeField(auto_now_add=True)
