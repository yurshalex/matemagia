"""GigaChatClient: OAuth-токен, запрос к API генерации, разбор ответа модели."""
import json
import logging
import re
import threading
import time
from uuid import uuid4

import requests
from django.conf import settings

from core.results import ResultCode, ServiceResult

logger = logging.getLogger(__name__)

OAUTH_URL = "https://ngw.devices.sberbank.ru:9443/api/v2/oauth"
API_URL = "https://api.giga.chat/v1/chat/completions"
TOKEN_RESERVE_MS = 60_000  # обновляем токен за минуту до истечения (срок жизни — 30 минут)

_FIELD_ALIASES = {
    "type": "task_type",
    "question": "condition",
    "text": "condition",
    "payload": "content_payload",
    "answer": "correct_answer",
    "solution": "explanation",
    "difficulty": "difficulty_level",
}


class _Unavailable(Exception):
    pass


class GigaChatClient:
    """Прямые HTTP-запросы через requests (SDK gigachat не используется).

    Ключ и токен не попадают в журнал и в браузер; TLS-сертификат всегда проверяется
    (при необходимости установите корневые сертификаты НУЦ Минцифры на сервере)."""

    def __init__(self, auth_key=None, timeout=None, scope=None, model=None, api_url=API_URL):
        self.api_url = api_url
        self.auth_key = settings.GIGACHAT_AUTH_KEY if auth_key is None else auth_key
        self.timeout = settings.GIGACHAT_TIMEOUT if timeout is None else timeout
        self.scope = scope or settings.GIGACHAT_SCOPE
        self.model = model or settings.GIGACHAT_MODEL
        self.access_token = None
        self.expires_at = 0  # миллисекунды Unix-времени
        self._lock = threading.Lock()

    def build_prompt(self, params) -> str:
        return (
            f"Составь одно задание по математике для {params['grade']} класса по теме «{params['topic_title']}». "
            f"Сложность: {params['difficulty_level']} из 3. Формат задания: {params['task_type']}. "
            'Требования к формату: choice — content_payload {"options": [4 варианта]}, correct_answer — один из вариантов; '
            "input — correct_answer число или обыкновенная дробь; boolean — correct_answer \"true\" или \"false\"; "
            'matching — content_payload {"left": [...], "right": [...]}, correct_answer — JSON-объект «элемент left: элемент right»; '
            'ordering — content_payload {"items": [...]}, correct_answer — JSON-список элементов в правильном порядке. '
            "Верни только JSON без пояснений с полями task_type, condition, content_payload, correct_answer, "
            "explanation, difficulty_level."
        )

    def _ensure_token(self):
        with self._lock:
            now_ms = time.time() * 1000
            if self.access_token and self.expires_at - TOKEN_RESERVE_MS > now_ms:
                return
            if not self.auth_key:
                raise _Unavailable("ключ авторизации не задан")
            try:
                response = requests.post(
                    OAUTH_URL,
                    headers={
                        "Authorization": f"Basic {self.auth_key}",
                        "RqUID": str(uuid4()),
                        "Content-Type": "application/x-www-form-urlencoded",
                        "Accept": "application/json",
                    },
                    data={"scope": self.scope},
                    timeout=self.timeout,
                )
                response.raise_for_status()
                payload = response.json()
                self.access_token = payload["access_token"]
                expires = int(payload.get("expires_at", now_ms + 25 * 60_000))
                self.expires_at = expires if expires > 10**11 else expires * 1000
            except (requests.RequestException, ValueError, KeyError) as exc:
                self.access_token = None
                raise _Unavailable(f"ошибка OAuth: {type(exc).__name__}") from exc

    def request_generation(self, params) -> ServiceResult:
        try:
            self._ensure_token()
            response = requests.post(
                self.api_url,
                headers={
                    "Authorization": f"Bearer {self.access_token}",
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                },
                json={
                    "model": self.model,
                    "messages": [{"role": "user", "content": self.build_prompt(params)}],
                    "stream": False,
                },
                timeout=self.timeout,
            )
            if response.status_code == 401:
                self.access_token = None
            response.raise_for_status()
            body = response.json()
        except _Unavailable as exc:
            logger.warning("GigaChat недоступен: %s", exc)
            return ServiceResult.fail(ResultCode.AI_UNAVAILABLE, {"ai": "GigaChat недоступен"})
        except requests.RequestException as exc:
            status = getattr(getattr(exc, "response", None), "status_code", None)
            logger.warning("Ошибка запроса к GigaChat: %s, HTTP %s", type(exc).__name__, status)
            return ServiceResult.fail(ResultCode.AI_UNAVAILABLE, {"ai": "GigaChat недоступен"})
        except ValueError:
            return ServiceResult.fail(ResultCode.AI_INVALID_RESPONSE, {"ai": "Ответ не является JSON"})

        try:
            content = body["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError):
            return ServiceResult.fail(ResultCode.AI_INVALID_RESPONSE, {"ai": "Нет текста ответа"})
        if not isinstance(content, str) or not content.strip():
            return ServiceResult.fail(ResultCode.AI_INVALID_RESPONSE, {"ai": "Пустой ответ"})
        return self.parse_response(content)

    def parse_response(self, response_text) -> ServiceResult:
        """Убирает обрамление Markdown, разбирает JSON и приводит поля к внутренней структуре."""
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", response_text.strip(), flags=re.IGNORECASE)
        try:
            data = json.loads(text)
        except ValueError:
            start, end = text.find("{"), text.rfind("}")
            try:
                data = json.loads(text[start : end + 1]) if 0 <= start < end else None
            except ValueError:
                data = None
        if not isinstance(data, dict):
            return ServiceResult.fail(ResultCode.AI_INVALID_RESPONSE, {"ai": "Не удалось разобрать JSON"})

        task = {}
        for key, value in data.items():
            task.setdefault(_FIELD_ALIASES.get(key, key), value)
        if isinstance(task.get("correct_answer"), (list, dict)):
            task["correct_answer"] = json.dumps(task["correct_answer"], ensure_ascii=False)
        elif task.get("correct_answer") is not None:
            task["correct_answer"] = str(task["correct_answer"]).strip()
        if isinstance(task.get("difficulty_level"), str) and task["difficulty_level"].strip().isdigit():
            task["difficulty_level"] = int(task["difficulty_level"])
        return ServiceResult.success(task)
