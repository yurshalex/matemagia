"""AdaptiveService: сложность, выбор задания, генерация через GigaChat и резервная выдача."""
import json
import logging
import random

from django.db import DatabaseError

from core.results import ResultCode, ServiceResult
from learning.models import Topic
from progress.models import UserProgress
from progress.services import ProgressService
from tests.checker import parse_number
from tests.models import Task

from .gigachat import GigaChatClient

logger = logging.getLogger(__name__)


class AdaptiveService:
    DIFFICULTY_MIN = 1
    DIFFICULTY_MAX = 3
    ADAPT_WINDOW = 5
    RECENT_EXCLUDE = 10
    WEAK_TOPIC_EVERY = 3

    def __init__(self, gigachat_client=None, progress_service=None):
        self.gigaChatClient = gigachat_client or GigaChatClient()
        self.progressService = progress_service or ProgressService()

    def determine_difficulty(self, user, topic_id) -> ServiceResult:
        progress = UserProgress.objects.filter(user=user, topic_id=topic_id).first()
        if progress is None:
            return ServiceResult.success(self.DIFFICULTY_MIN)

        current = progress.difficulty_level
        solved = progress.tasks_solved
        # пересмотр после каждого пятого ответа; при том же tasks_solved уровень повторно не меняется
        if solved < self.ADAPT_WINDOW or solved % self.ADAPT_WINDOW != 0 or progress.difficulty_reviewed_at == solved:
            return ServiceResult.success(current)

        correct = self.progressService.get_recent_accuracy(user, topic_id, self.ADAPT_WINDOW).data["correct"]
        level = current
        if correct >= 4:
            level = min(current + 1, self.DIFFICULTY_MAX)
        elif correct <= 2:
            level = max(current - 1, self.DIFFICULTY_MIN)

        progress.difficulty_level = level
        progress.difficulty_reviewed_at = solved
        progress.save(update_fields=["difficulty_level", "difficulty_reviewed_at"])
        return ServiceResult.success(level)

    def pick_next_task(self, user, topic_id, task_type, difficulty=None, task_number=1) -> ServiceResult:
        if topic_id is not None:
            topic = Topic.objects.filter(pk=topic_id).first()
            if topic is None:
                return ServiceResult.fail(ResultCode.NOT_FOUND, {"topic": "Тема не найдена"})
        else:
            topic = self._recommended_topic(user, task_number)
            if topic is None:
                return ServiceResult.fail(ResultCode.NO_TASKS_AVAILABLE, {"tasks": "Нет доступных тем"})

        level = difficulty if difficulty is not None else self.determine_difficulty(user, topic.pk).data
        recent_ids = self.progressService.get_recent_task_ids(user, self.RECENT_EXCLUDE)

        params = self.build_generation_params(topic, level, task_type or random.choice(Task.TYPE_CODES))
        if params.ok:
            generated = self.generate_task(params.data)
            if generated.ok:
                return generated
            logger.info("Генерация не удалась (код %s), используется резервное задание", generated.code)
        return self.get_fallback_task(topic.pk, task_type, level, recent_ids)

    def _recommended_topic(self, user, task_number):
        weak = self.progressService.get_weak_topics(user).data
        if weak and task_number % self.WEAK_TOPIC_EVERY == 0:
            return Topic.objects.filter(pk=random.choice(weak)["topic_id"]).first()
        return Topic.objects.order_by("?").first()

    def build_generation_params(self, topic, difficulty, task_type) -> ServiceResult:
        errors = {}
        if difficulty not in range(self.DIFFICULTY_MIN, self.DIFFICULTY_MAX + 1):
            errors["difficulty"] = "Недопустимая сложность"
        if task_type not in Task.TYPE_CODES:
            errors["task_type"] = "Недопустимый формат"
        if errors:
            return ServiceResult.fail(ResultCode.VALIDATION_ERROR, errors)
        # учётные данные и история ученика во внешний сервис не передаются
        return ServiceResult.success(
            {"topic_id": topic.pk, "topic_title": topic.title, "grade": 5, "difficulty_level": difficulty, "task_type": task_type}
        )

    def generate_task(self, params) -> ServiceResult:
        raw = self.gigaChatClient.request_generation(params)
        if not raw.ok:
            return raw
        valid = self.validate_generated_task(raw.data, params)
        if not valid.ok:
            return valid
        d = valid.data
        try:
            task = Task.objects.create(
                topic_id=params["topic_id"], task_type=d["task_type"], condition=d["condition"],
                content_payload=d["content_payload"], correct_answer=d["correct_answer"],
                explanation=d["explanation"], difficulty_level=d["difficulty_level"], is_ai_generated=True,
            )
        except DatabaseError:
            logger.exception("Не удалось сохранить сгенерированное задание")
            return ServiceResult.fail(ResultCode.INTERNAL_ERROR, {"__all__": "Ошибка записи в БД"})
        return ServiceResult.success(task)

    def validate_generated_task(self, raw_task, params) -> ServiceResult:
        def invalid(reason):
            return ServiceResult.fail(ResultCode.AI_INVALID_RESPONSE, {"ai": reason})

        if not isinstance(raw_task, dict):
            return invalid("Ответ не является заданием")
        for name in ("task_type", "condition", "correct_answer", "explanation", "difficulty_level"):
            if raw_task.get(name) in (None, ""):
                return invalid(f"Нет поля {name}")

        kind = raw_task["task_type"]
        if kind not in Task.TYPE_CODES or kind != params["task_type"]:
            return invalid("Формат не совпадает с запрошенным")
        try:
            level = int(raw_task["difficulty_level"])
        except (TypeError, ValueError):
            return invalid("Некорректная сложность")
        if level != params["difficulty_level"]:
            return invalid("Сложность не совпадает с запрошенной")

        payload = raw_task.get("content_payload")
        answer = str(raw_task["correct_answer"]).strip()
        try:
            if kind == "choice":
                options = [str(o).strip() for o in (payload or {}).get("options", [])]
                if len(options) < 2 or len(set(options)) != len(options) or answer not in options:
                    return invalid("Эталонный ответ не входит в варианты")
                payload = {"options": options}
            elif kind == "input":
                parse_number(answer)
                payload = None
            elif kind == "boolean":
                answer = answer.lower()
                if answer not in ("true", "false"):
                    return invalid("Ответ boolean должен быть true или false")
                payload = None
            elif kind == "ordering":
                items = [str(x).strip() for x in (payload or {}).get("items", [])]
                expected = json.loads(answer)
                if len(items) < 2 or not isinstance(expected, list) or sorted(map(str, expected)) != sorted(items):
                    return invalid("Некорректная структура ordering")
                payload, answer = {"items": items}, json.dumps([str(x) for x in expected], ensure_ascii=False)
            elif kind == "matching":
                left = [str(x).strip() for x in (payload or {}).get("left", [])]
                right = [str(x).strip() for x in (payload or {}).get("right", [])]
                expected = json.loads(answer)
                if (
                    len(left) < 2 or len(left) != len(right) or not isinstance(expected, dict)
                    or sorted(map(str, expected)) != sorted(left)
                    or sorted(map(str, expected.values())) != sorted(right)
                ):
                    return invalid("Некорректная структура matching")
                payload = {"left": left, "right": right}
                answer = json.dumps({str(k): str(v) for k, v in expected.items()}, ensure_ascii=False)
        except (ValueError, TypeError, AttributeError):
            return invalid("Некорректные данные формата")

        return ServiceResult.success(
            {
                "task_type": kind,
                "condition": str(raw_task["condition"]).strip(),
                "content_payload": payload,
                "correct_answer": answer,
                "explanation": str(raw_task["explanation"]).strip(),
                "difficulty_level": level,
            }
        )

    def get_fallback_task(self, topic_id, task_type, difficulty, exclude_ids) -> ServiceResult:
        """Критерии ослабляются: тема+формат+сложность -> тема+формат -> тема."""
        base = Task.objects.filter(topic_id=topic_id, is_ai_generated=False).exclude(pk__in=list(exclude_ids or []))
        for criteria in ({"task_type": task_type, "difficulty_level": difficulty}, {"task_type": task_type}, {}):
            criteria = {k: v for k, v in criteria.items() if v is not None}
            ids = list(base.filter(**criteria).values_list("pk", flat=True))
            if ids:
                return ServiceResult.success(Task.objects.get(pk=random.choice(ids)))
        return ServiceResult.fail(ResultCode.NO_TASKS_AVAILABLE, {"tasks": "Подходящих заданий нет"})
