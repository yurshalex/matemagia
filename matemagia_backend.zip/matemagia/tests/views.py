"""TaskViews: выбор задания, условие, приём ответа."""
import json

from django.contrib.auth.decorators import login_required
from django.http import Http404, JsonResponse
from django.shortcuts import redirect, render
from django.views.decorators.http import require_GET, require_POST

from core.results import ResultCode
from learning.models import Topic

from .forms import AnswerForm
from .models import Task
from .services import TaskService

task_service = TaskService()


def _is_ajax(request) -> bool:
    return (
        request.headers.get("X-Requested-With") == "XMLHttpRequest"
        or "application/json" in request.headers.get("Accept", "")
        or request.content_type == "application/json"
    )


def _form_context(**extra):
    context = {"topics": Topic.objects.all(), "task_types": Task.TYPES, "errors": {}}
    context.update(extra)
    return context


def _pick_and_redirect(request, task_number):
    ajax = _is_ajax(request)
    topic_raw, type_raw = request.GET.get("topic"), request.GET.get("type")
    topic_id = None
    if topic_raw:
        if not topic_raw.isdigit():
            if ajax:
                return JsonResponse({"errors": {"topic": "Недопустимая тема"}}, status=400)
            return render(request, "tests/task_list.html", _form_context(errors={"topic": "Недопустимая тема"}), status=400)
        topic_id = int(topic_raw)
    task_type = type_raw or None
    request.session["task_number"] = task_number

    result = task_service.get_next_task(request.user, topic_id, task_type, task_number=task_number)
    if result.ok:
        if ajax:  # фронтенд (task_check.js) получает задание JSON-ом
            return JsonResponse({**result.data, "task_number": task_number})
        return redirect(f"/tasks/{result.data['id']}/")

    status = {ResultCode.VALIDATION_ERROR: 400, ResultCode.NOT_FOUND: 404, ResultCode.NO_TASKS_AVAILABLE: 404}.get(
        result.code, 500
    )
    if status == 500:
        raise RuntimeError(f"get_next_task failed: {result.code} {result.errors}")
    if ajax:
        return JsonResponse({"errors": result.errors}, status=status)
    return render(request, "tests/task_list.html", _form_context(errors=result.errors), status=status)


@login_required
@require_GET
def task_list_view(request):
    if not request.GET.get("topic") and not request.GET.get("type"):
        return render(request, "tests/task_list.html", _form_context())
    return _pick_and_redirect(request, task_number=1)  # новая серия тренировки


@login_required
@require_GET
def next_task_view(request):
    """Следующее задание серии: номер задания хранится в сессии."""
    number = int(request.session.get("task_number", 0)) + 1
    return _pick_and_redirect(request, task_number=number)


@login_required
@require_GET
def task_detail_view(request, task_id):
    result = task_service.get_task(task_id)
    if result.code == ResultCode.NOT_FOUND:
        raise Http404("Задание не найдено")
    task = result.data
    topic = Topic.objects.filter(pk=task["topic_id"]).first()
    return render(
        request, "tests/task_trainer.html",
        {"task": task, "topic": topic, "task_number": request.session.get("task_number", 1)},
    )


@require_POST
def check_answer_view(request, task_id):
    ajax = _is_ajax(request)
    if not request.user.is_authenticated:
        if ajax:
            return JsonResponse({"error": "Требуется вход в систему"}, status=401)
        return redirect(f"/login/?next=/tasks/{task_id}/")

    if request.content_type == "application/json":  # ответ может быть списком/объектом
        try:
            answer = json.loads(request.body or b"{}").get("answer")
        except (ValueError, AttributeError):
            answer = None
    else:
        form = AnswerForm(request.POST)
        answer = form.cleaned_data["answer"] if form.is_valid() else None
    if answer is None or answer == "":
        return _error(request, ajax, {"answer": "Ответ не указан"}, 400)

    result = task_service.check_answer(request.user, task_id, answer)
    if result.ok:
        if ajax:
            return JsonResponse(result.data)
        task = task_service.get_task(task_id).data
        return render(request, "tests/result.html", {"result": result.data, "task": task})
    if result.code == ResultCode.NOT_FOUND:
        raise Http404("Задание не найдено")
    if result.code in (ResultCode.INVALID_ANSWER_FORMAT, ResultCode.VALIDATION_ERROR):
        return _error(request, ajax, result.errors, 400)
    raise RuntimeError(f"check_answer failed: {result.code} {result.errors}")


def _error(request, ajax, errors, status):
    if ajax:
        return JsonResponse({"errors": errors}, status=status)
    return render(request, "tests/result.html", {"result": None, "errors": errors}, status=status)
