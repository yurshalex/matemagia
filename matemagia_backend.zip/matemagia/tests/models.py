from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models


class Task(models.Model):
    """Задание (таблица tasks_task)."""

    CHOICE, INPUT, MATCHING, BOOLEAN, ORDERING = "choice", "input", "matching", "boolean", "ordering"
    TYPES = [
        (CHOICE, "Выбор ответа"),
        (INPUT, "Ввод числа"),
        (MATCHING, "Сопоставление"),
        (BOOLEAN, "Правда/ложь"),
        (ORDERING, "Порядок действий"),
    ]
    TYPE_CODES = tuple(code for code, _ in TYPES)

    topic = models.ForeignKey("learning.Topic", on_delete=models.CASCADE, related_name="tasks")
    task_type = models.CharField("Тип задания", max_length=30, choices=TYPES)
    condition = models.TextField("Условие")
    # choice: {"options": [...]}; matching: {"left": [...], "right": [...]}; ordering: {"items": [...]}
    content_payload = models.JSONField("Данные формата", null=True, blank=True)
    # choice/input: строка; boolean: "true"/"false"; matching: JSON-объект; ordering: JSON-список
    correct_answer = models.TextField("Эталонный ответ")
    explanation = models.TextField("Объяснение", null=True, blank=True)
    difficulty_level = models.IntegerField(
        "Сложность", default=1, validators=[MinValueValidator(1), MaxValueValidator(3)]
    )
    is_ai_generated = models.BooleanField("Сгенерировано GigaChat", default=False)

    class Meta:
        db_table = "tasks_task"

    def __str__(self) -> str:
        return f"[{self.task_type}/{self.difficulty_level}] {self.condition[:50]}"
