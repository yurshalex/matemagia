"""AnswerChecker: проверка ответов по правилам каждого формата и объяснения."""
import json
import re
from fractions import Fraction

from core.results import ResultCode, ServiceResult

_NUMBER_RE = re.compile(r"^[+-]?\d+(?:\.\d+)?$")
_FRACTION_RE = re.compile(r"^[+-]?\d+/\d+$")


def parse_number(text) -> Fraction:
    """Число или обыкновенная дробь -> Fraction (ValueError, если не удалось).

    Нормализация: удаляются пробелы, «,» заменяется на «.» (1/2 и 0,5 равны)."""
    normalized = re.sub(r"\s+", "", str(text)).replace(",", ".")
    if _NUMBER_RE.match(normalized) or _FRACTION_RE.match(normalized):
        try:
            return Fraction(normalized)
        except ZeroDivisionError as exc:
            raise ValueError("zero denominator") from exc
    raise ValueError("not a number")


def load_json(value):
    return json.loads(value) if isinstance(value, str) else value


def format_correct_answer(task) -> str:
    raw = str(task.correct_answer).strip()
    try:
        if task.task_type == "boolean":
            return "верно" if raw.lower() == "true" else "неверно"
        if task.task_type == "ordering":
            return " → ".join(map(str, json.loads(raw)))
        if task.task_type == "matching":
            return "; ".join(f"{k} — {v}" for k, v in json.loads(raw).items())
    except (ValueError, AttributeError):
        pass
    return raw


class AnswerChecker:
    def __init__(self):
        self.handlers = {
            "choice": self._check_exact,
            "boolean": self._check_boolean,
            "input": self._check_input,
            "matching": self._check_matching,
            "ordering": self._check_ordering,
        }

    def check(self, task, answer) -> ServiceResult:
        handler = self.handlers.get(task.task_type)
        if handler is None:
            return ServiceResult.fail(ResultCode.VALIDATION_ERROR, {"task_type": "Неизвестный формат задания"})
        try:
            return ServiceResult.success(bool(handler(task, answer)))
        except (ValueError, TypeError, KeyError, AttributeError):
            return ServiceResult.fail(ResultCode.INVALID_ANSWER_FORMAT, {"answer": "Ответ не удалось сравнить"})

    def build_explanation(self, task, is_correct: bool) -> ServiceResult:
        base = (task.explanation or "").strip()
        if is_correct:
            return ServiceResult.success(base or "Верно!")
        tail = f"Правильный ответ: {format_correct_answer(task)}."
        return ServiceResult.success(f"Неверно. {base} {tail}" if base else f"Неверно. {tail}")

    @staticmethod
    def _check_exact(task, answer):
        return str(answer).strip() == str(task.correct_answer).strip()

    @staticmethod
    def _check_boolean(task, answer):
        return str(answer).strip().lower() == str(task.correct_answer).strip().lower()

    @staticmethod
    def _check_input(task, answer):
        return parse_number(answer) == parse_number(task.correct_answer)

    @staticmethod
    def _check_matching(task, answer):
        given = {(str(k), str(v)) for k, v in load_json(answer).items()}
        expected = {(str(k), str(v)) for k, v in load_json(task.correct_answer).items()}
        return given == expected

    @staticmethod
    def _check_ordering(task, answer):
        return [str(x) for x in load_json(answer)] == [str(x) for x in load_json(task.correct_answer)]
