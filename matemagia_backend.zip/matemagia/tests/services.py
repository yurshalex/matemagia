"""TaskService: выдача заданий, проверка формата ответа, сохранение попытки, начисление опыта."""
import json
import logging
import random

from django.db import DatabaseError, transaction

from adaptive.services import AdaptiveService
from core.results import ResultCode, ServiceResult
from game.services import RewardService
from progress.services import ProgressService

from .checker import AnswerChecker, load_json, parse_number
from .models import Task

logger = logging.getLogger(__name__)


class _Abort(Exception):
    def __init__(self, result: ServiceResult):
        self.result = result


def _stable_shuffle(items, seed):
    items = list(items)
    random.Random(seed).shuffle(items)
    return items


def public_task(task: Task) -> dict:
    """Задание для ученика: без correct_answer и explanation.

    Варианты перемешиваются стабильно (по id), чтобы порядок не подсказывал ответ."""
    payload = dict(task.content_payload) if isinstance(task.content_payload, dict) else task.content_payload
    if isinstance(payload, dict):
        if task.task_type == "choice" and "options" in payload:
            payload["options"] = _stable_shuffle(payload["options"], task.pk)
        elif task.task_type == "ordering" and "items" in payload:
            payload["items"] = _stable_shuffle(payload["items"], task.pk)
        elif task.task_type == "matching" and "right" in payload:
            payload["right"] = _stable_shuffle(payload["right"], task.pk)
    return {
        "id": task.pk,
        "topic_id": task.topic_id,
        "task_type": task.task_type,
        "condition": task.condition,
        "content_payload": payload,
        "difficulty_level": task.difficulty_level,
    }


class TaskService:
    def __init__(self, adaptive_service=None, answer_checker=None, progress_service=None, reward_service=None):
        self.adaptiveService = adaptive_service or AdaptiveService()
        self.answerChecker = answer_checker or AnswerChecker()
        self.progressService = progress_service or ProgressService()
        self.rewardService = reward_service or RewardService()

    def get_next_task(self, user, topic_id, task_type, difficulty=None, task_number=1) -> ServiceResult:
        errors = {}
        if task_type is not None and task_type not in Task.TYPE_CODES:
            errors["type"] = "Недопустимый формат задания"
        if difficulty is not None and difficulty not in (1, 2, 3):
            errors["difficulty"] = "Сложность должна быть от 1 до 3"
        if errors:
            return ServiceResult.fail(ResultCode.VALIDATION_ERROR, errors)

        result = self.adaptiveService.pick_next_task(user, topic_id, task_type, difficulty, task_number)
        if not result.ok:
            return result
        return ServiceResult.success(public_task(result.data))

    def get_task(self, task_id) -> ServiceResult:
        task = Task.objects.filter(pk=task_id).first()
        if task is None:
            return ServiceResult.fail(ResultCode.NOT_FOUND, {"task": "Задание не найдено"})
        return ServiceResult.success(public_task(task))

    def validate_answer_format(self, task, raw_answer) -> ServiceResult:
        def bad(message):
            return ServiceResult.fail(ResultCode.INVALID_ANSWER_FORMAT, {"answer": message})

        payload = task.content_payload or {}
        kind = task.task_type

        if kind == "choice":
            value = "" if raw_answer is None else str(raw_answer).strip()
            if value not in [str(o) for o in payload.get("options", [])]:
                return bad("Выберите один из предложенных вариантов")
            return ServiceResult.success(value)

        if kind == "input":
            value = "" if raw_answer is None else str(raw_answer).strip()
            try:
                parse_number(value)
            except ValueError:
                return bad("Введите число или обыкновенную дробь")
            return ServiceResult.success(value)

        if kind == "boolean":
            value = "" if raw_answer is None else str(raw_answer).strip().lower()
            if value not in ("true", "false"):
                return bad("Ответ должен быть true или false")
            return ServiceResult.success(value)

        if kind in ("matching", "ordering"):
            try:
                obj = load_json(raw_answer)
            except ValueError:
                return bad("Ответ должен быть корректным JSON")
            if kind == "ordering":
                items = [str(x) for x in payload.get("items", [])]
                if not isinstance(obj, list) or sorted(map(str, obj)) != sorted(items):
                    return bad("Нужно расположить каждый элемент ровно один раз")
            else:
                left = [str(x) for x in payload.get("left", [])]
                right = {str(x) for x in payload.get("right", [])}
                if (
                    not isinstance(obj, dict)
                    or sorted(map(str, obj.keys())) != sorted(left)
                    or not {str(v) for v in obj.values()} <= right
                ):
                    return bad("Нужно сопоставить каждый элемент левой колонки ровно один раз")
            return ServiceResult.success(obj)

        return bad("Неизвестный формат задания")

    def check_answer(self, user, task_id, raw_answer, record_xp=True) -> ServiceResult:
        task = Task.objects.filter(pk=task_id).first()
        if task is None:
            return ServiceResult.fail(ResultCode.NOT_FOUND, {"task": "Задание не найдено"})

        fmt = self.validate_answer_format(task, raw_answer)
        if not fmt.ok:
            return fmt  # попытка не сохраняется
        checked = self.answerChecker.check(task, fmt.data)
        if not checked.ok:
            return checked
        is_correct = checked.data
        explanation = self.answerChecker.build_explanation(task, is_correct).data
        stored_answer = raw_answer if isinstance(raw_answer, str) else json.dumps(raw_answer, ensure_ascii=False)

        try:
            with transaction.atomic():
                xp_earned = 0
                if is_correct and record_xp:
                    streak = (self.rewardService.get_streak(user).data or 0) + 1  # включая текущий ответ
                    xp = self.rewardService.calculate_xp(task.difficulty_level, streak)
                    if not xp.ok:
                        raise _Abort(xp)
                    xp_earned = xp.data
                fixed_error = is_correct and self.progressService.last_attempt_incorrect(user, task.pk)

                recorded = self.progressService.record_attempt(user, task, stored_answer, is_correct, xp_earned)
                if not recorded.ok:
                    raise _Abort(recorded)

                rank, rank_changed, new_achievements = user.current_rank, False, []
                if is_correct and record_xp:
                    context = {"fixed_error": True} if fixed_error else None
                    award = self.rewardService.award_xp(user, xp_earned, context=context)
                    if not award.ok:
                        raise _Abort(award)
                    rank = award.data["rank"]
                    rank_changed = award.data["rank_changed"]
                    new_achievements = award.data["new_achievements"]
        except _Abort as exc:
            return exc.result
        except DatabaseError:
            logger.exception("Ошибка записи в БД при проверке ответа")
            return ServiceResult.fail(ResultCode.INTERNAL_ERROR, {"__all__": "Внутренняя ошибка"})

        return ServiceResult.success(
            {
                "is_correct": is_correct,
                "explanation": explanation,
                "correct_answer": task.correct_answer,  # раскрывается только после проверки
                "xp_earned": xp_earned,
                "rank": rank,
                "rank_changed": rank_changed,
                "new_achievements": new_achievements,
            }
        )
