from django import forms


class AnswerForm(forms.Form):
    """Ответ приходит строкой; для matching и ordering это JSON-строка."""

    answer = forms.CharField(strip=True)
