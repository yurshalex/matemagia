from django.contrib import admin

from .models import Task


@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ("id", "topic", "task_type", "difficulty_level", "is_ai_generated", "condition")
    list_filter = ("topic", "task_type", "difficulty_level", "is_ai_generated")
    search_fields = ("condition",)
