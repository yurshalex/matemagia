# МатеМагия — бэкенд (Django)

Только серверная часть по «Документу проектирования». Фронтенд (ветка `frontend` репозитория) кладётся в
`templates/` и `static/` (здесь только `.gitkeep`).

## Запуск
```bash
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
python manage.py makemigrations users learning tests progress game
python manage.py migrate
python manage.py loaddata initial_data.json       # 8 тем, уроки, 96 заданий, 8 достижений
python manage.py createsuperuser
python manage.py runserver 0.0.0.0:8000
```
Без `GIGACHAT_AUTH_KEY` выдаются только заготовленные задания из БД. `python tools/generate_initial_data.py`
пересоздаёт фикстуру. Приложение `tests` названо как в документе; если Django будет путать его с тестами — переименуйте.

## Состав
config · core (ServiceResult, главная) · users (AuthService) · learning (LearningService) · tests (TaskService,
AnswerChecker) · adaptive (AdaptiveService, GigaChatClient) · progress (ProgressService) · game (RewardService,
ChallengeService). Дополнение к 8 таблицам документа: `game_challengeresult` (итоги испытаний — для достижения
«Три испытания» и счётчика в кабинете).

## Контракт для фронтенда (шаблон → контекст)
В формах `{% csrf_token %}`; выход — только POST на `/logout/`. Нужны также `404.html`, `500.html`.

| Шаблон | Контекст |
|---|---|
| `home.html` | — |
| `dashboard_main.html` | `rank_info`, `weak_topics` |
| `users/auth_login.html` | `errors` (`__all__` — общая), `values`, `next`; поля `username`, `password` |
| `users/register.html` | `errors`, `values`; поля `first_name`, `grade`, `username`, `password1`, `password2` |
| `progress/profile_stats.html` | `profile_user`, `stats`, `topic_progress`, `weak_topics`, `recent_attempts`, `rank_info`, `achievements`, `challenges_passed` |
| `learning/topic_catalog.html` | `topics`: `topic`, `status`, `status_code` (new/in_progress/done), `tasks_done`, `tasks_total`, `progress_percent` |
| `learning/topic_detail.html` | `topic`, `lessons` |
| `learning/theory_view.html` | `lesson`, `topic`, `lessons`, `number`, `total`, `prev_id`, `next_id` |
| `tests/task_list.html` | `topics`, `task_types`, `errors` |
| `tests/task_trainer.html` | `task`, `topic`, `task_number` |
| `tests/result.html` | `result`, `task` или `errors` |
| `progress/progress.html` | `stats`, `topic_progress` |
| `progress/history.html` | `attempts`, `page`, `num_pages`, `has_next`, `has_previous`, `total` |
| `progress/weak_topics.html` | `weak_topics`, `error_tasks` |
| `game/challenge_game.html` | `mode="start"`: `rank_info` (с `ranks`, `next_threshold`), `topics`, `challenge_params`; `mode="task"`: `task`, `position`, `total`, `errors` |
| `game/game_result.html` | `result` |
| `game/achievements_list.html` | `rank_info`, `achievements` (`achievements`, `unlocked_count`, `total_count`) |

### Задания (для `task_check.js`)
- `GET /tasks/next/?topic=<id>&type=<тип>` с заголовком `X-Requested-With: XMLHttpRequest` возвращает JSON задания:
  `{id, topic_id, task_type, condition, content_payload, difficulty_level, task_number}` (без ответа и объяснения).
  Без `topic` — режим рекомендаций. Новая серия начинается с `GET /tasks/?topic=<id>`.
- `POST /tasks/<id>/check/` — `answer` (форма) или JSON `{"answer": ...}`; ответ JSON:
  `{is_correct, explanation, correct_answer, xp_earned, rank, rank_changed, new_achievements}`.
- «Испытание»: `POST /game/start/` с полем `topic_id` (поле `topic` тоже принимается), затем `POST /game/` с `answer`.

| Тип | `content_payload` | `answer` |
|---|---|---|
| choice | `{"options": [...]}` | один из вариантов (текст) |
| input | — | число или дробь (`0,5`, `1/2`) |
| boolean | — | `"true"` / `"false"` |
| matching | `{"left": [...], "right": [...]}` | JSON `{"левый": "правый"}` |
| ordering | `{"items": [...]}` | JSON-список в нужном порядке |

Важно: радиокнопки варианта должны отправлять **текст варианта**, а не индекс (в прототипе `value="i"`).
