"""MainViews: главная страница (гость / дашборд обучающегося)."""
from django.shortcuts import render
from django.views.decorators.http import require_GET

from game.services import RewardService
from progress.services import ProgressService


class MainViews:
    reward_service = RewardService()
    progress_service = ProgressService()


@require_GET
def home_view(request):
    """GET / — home.html для гостя, dashboard_main.html для авторизованного."""
    if not request.user.is_authenticated:
        return render(request, "home.html")

    rank = MainViews.reward_service.get_rank_info(request.user)
    weak = MainViews.progress_service.get_weak_topics(request.user)
    return render(
        request,
        "dashboard_main.html",
        {"rank_info": rank.data if rank.ok else None, "weak_topics": weak.data if weak.ok else []},
    )
